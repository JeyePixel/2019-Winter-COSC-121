package ianhealesexercise1;

public class Person {
	
	private String name;
	private String address;
	private String phone;
	private String email;
	private static int count;
	
	//Constructor
	public Person() {
		count++;
	}
	public Person(String name, String address, String phone, String email) {
		setName(name);
		setAddress(address);
		setPhone(phone);
		setEmail(email);
		count++;
	}
	
	//Getter methods
	public String getName() { return name; }
	public String getAddress() { return address; }
	public String getPhone() { return phone; }
	public String getEmail() { return email; }
	public static int getCount() { return count; }
	public String toString() { return "name: " + getName() + ", address: " + getAddress() + ", phone: " + getPhone() + ", email: " + getEmail();} 
	
	//Setter methods
	public void setName(String s) { name = s; }
	public void setAddress(String s) { address = s; }
	public void setPhone(String s) { phone = s; }
	public void setEmail(String s) { email = s; }
	
}