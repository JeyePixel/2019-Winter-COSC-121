package ianhealesexercise1;

class Student extends Person {
	
	private String status;
	
	//Constructor
	public Student() {
		super();
	}
	public Student(String name, String address, String phone, String email, String status) {
		super(name,address,phone,email);
		setStatus(status);
	}
	
	//Getter methods
	public String getStatus() { return status; }
	public String toString() { return "name: " + getName() + ", address: " + getAddress() + ", phone: " + getPhone() + ", email: " + getEmail() + ", status: " + getStatus();} 
	
	//Setter methods
	public void setStatus(String s) { status = s; }
	
}