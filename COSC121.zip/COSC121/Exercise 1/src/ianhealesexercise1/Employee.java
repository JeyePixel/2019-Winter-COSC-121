package ianhealesexercise1;

import java.util.Date;

public class Employee extends Person{
	
	private String office;
	private int salary;
	private Date dateHired;
	
	//Constructor
	public Employee() {
		super();
	}
	public Employee(String name, String address, String phone, String email, String office, int salary, Date date) {
		super(name,address,phone,email);
		setOffice(office);
		setSalary(salary);
		setDateHired(date);
	}
	//Getter methods
	public String getOffice() {return office;}
	public int getSalary() {return salary;}
	public Date getDateHired() {return dateHired;}
	public String toString() { return "name: " + getName() + ", address: " + getAddress() + ", phone: " + getPhone() + ", email: " + getEmail() + ", office: " + getOffice() + ", salary: " + getSalary() + ", date hired: " + getDateHired();}
	
	//Setter methods
	public void setOffice(String s) {office = s;}
	public void setSalary(int i) {salary = i;}
	public void setDateHired(Date d) {dateHired = d;}
	
}
