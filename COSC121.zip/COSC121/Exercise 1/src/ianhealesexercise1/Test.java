package ianhealesexercise1;

public class Test {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		Person p2 = new Student();
		Person p3 = new Employee();
		Person p4 = new Staff();
		Person p5 = new Faculty();
		
		System.out.println(Person.getCount());

	}

}
