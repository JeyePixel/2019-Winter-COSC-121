package ianhealesexercise1;

import java.util.Date;

public class Staff extends Employee{
	
	private String title;
	
	//Constructors
	public Staff() {
		super();
	}
	
	public Staff(String name, String address, String phone, String email, String office, int salary, Date date, String title) {
		super(name,address,phone,email,office,salary,date);
		setTitle(title);
	}
	
	//Getter methods
	public String getTitle() {return title;}
	public String toString() { return "name: " + getName() + ", address: " + getAddress() + ", phone: " + getPhone() + ", email: " + getEmail() + ", office: " + getOffice() + ", salary: " + getSalary() + ", date hired: " + getDateHired() + ", title: " + getTitle();}
	
	//Setter methods
	public void setTitle(String s) {title = s;}
}
