package ianhealesexercise1;

import java.util.Date;

public class Faculty extends Employee{
	
	private String officeHour;
	private String rank;
	
	//Constructor
	public Faculty() {
		super();
	}
	public Faculty(String name, String address, String phone, String email, String office, int salary, Date date, String OfficeHour, String rank) {
		super(name,address,phone,email,office,salary,date);
		setOfficeHour(officeHour);
		setRank(rank);
		
	}
	
	//Getter Methods
	public String getOfficeHour() {return officeHour;}
	public String getRank() {return rank;}
	public String toString() { return "name: " + getName() + ", address: " + getAddress() + ", phone: " + getPhone() + ", email: " + getEmail() + ", office: " + getOffice() + ", salary: " + getSalary() + ", date hired: " + getDateHired() + ", office hour: " + getOfficeHour() + ", rank: " + getRank();}
	
	//Setter Methods
	public void setRank(String s) {rank = s;}
	public void setOfficeHour(String s) {officeHour = s;}

}
