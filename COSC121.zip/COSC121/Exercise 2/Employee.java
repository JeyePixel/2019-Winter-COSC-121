package exerciseset2;

public class Employee extends StaffMember {
	
	private String SIN;
	private double payRate;
	
	public Employee() {super();}
	public Employee(String name, String address, String phone, String SIN, double payRate) {
		super(name, address, phone);
		this.setPayRate(payRate);
		this.setSIN(SIN);
	}
	public String getSIN() {
		return SIN;
	}
	public void setSIN(String sIN) {
		SIN = sIN;
	}
	public double getPayRate() {
		return payRate;
	}
	public void setPayRate(double payRate) {
		this.payRate = payRate;
	}
	public double pay() {
		System.out.println(this.getName() + " was paid!");
		return this.getPayRate();
	}
}
