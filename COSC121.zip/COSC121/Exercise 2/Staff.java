package exerciseset2;

public class Staff {
	
	StaffMember[] staffMemberArray = new StaffMember[5];
	
	public Staff() {
		staffMemberArray[0] = new Volunteer("Ben", "4567 king road", "2507778849");
		staffMemberArray[1] = new Employee("Seth", "4567 king road", "2507778849", "EmployeeSIN", 50);
		staffMemberArray[2] = new Executive("Carey", "4567 king road", "2507778849", "EmployeeSIN", 50, 5000);
		staffMemberArray[3] = new Hourly("Raj", "4567 king road", "2507778849", "EmployeeSIN", 50, 500);
		staffMemberArray[4] = new Hourly("Stephany", "4567 king road", "2507778849", "EmployeeSIN", 50, 500);
	}
	void payday() {
		for(StaffMember staff: staffMemberArray) {
			if(!(staff instanceof Volunteer)) {staff.pay();}
		}
	}
	void employeeInfo() {
		for(StaffMember staff: staffMemberArray) {
			staff.toString();
		}
		
	}

}
