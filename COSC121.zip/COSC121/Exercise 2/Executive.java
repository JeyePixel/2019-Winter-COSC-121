package exerciseset2;

public class Executive extends Employee {
	
	private double bonus;
	
	public Executive() {super();}
	public Executive(String name, String address, String phone, String SIN, double payRate, double bonus) {
		super(name, address, phone, SIN, payRate);
		this.setBonus(bonus);
	}

	public double getBonus() {
		return bonus;
	}
	public void setBonus(double bonus) {
		this.bonus = bonus;
	}
	public void awardBonus() {
		
	}
	
	public double pay() {
		System.out.println(this.getName() + " was paid!");
		return this.getPayRate();
	}
}
