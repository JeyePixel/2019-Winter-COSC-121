package exerciseset2;

public class Firm {

	public static void main(String[] args) {
	
		Staff staff = new Staff();
		
		staff.payday();
		System.out.println(staff.staffMemberArray[0].toString());
		System.out.println(staff.staffMemberArray[1].toString());
		System.out.println(staff.staffMemberArray[2].toString());
		System.out.println(staff.staffMemberArray[3].toString());
		System.out.println(staff.staffMemberArray[4].toString());

	}

}
