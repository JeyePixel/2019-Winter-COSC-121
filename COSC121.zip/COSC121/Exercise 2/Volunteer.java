package exerciseset2;

public class Volunteer extends StaffMember {
	
	public Volunteer() {super();}
	public Volunteer(String name, String address, String phone) {
		super(name, address, phone);
	}
	public double pay() {
		return 0;
	}

}
