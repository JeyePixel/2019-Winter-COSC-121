package exerciseset2;

public class Hourly extends Employee {
	
	private int hoursWorked;
	public Hourly() {super();}
	public Hourly(String name, String address, String phone, String SIN, double payRate, int hoursWorked) {
		super(name, address, phone, SIN, payRate);
		this.setHoursWorked(hoursWorked);
	}
	public int getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	
	public double pay() {
		System.out.println(this.getName() + " was paid!");
		return this.getPayRate();
	}
	
}
