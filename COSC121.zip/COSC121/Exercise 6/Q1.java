/*
 * For this problem, I started out by making a method. 
 * In this method, it creates a new File object and checks if the file path exists.
 * If it does, it reads in the integer from the file, increments it, and writes the new integer back into the file.
 * If the file does not exist, an integer of 0 is written to it.
 * Input and Output streams had to be kept separate so this program could read and write properly.
 */
package assignment4;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Q1 {

	public static void main(String[] args) throws Exception {
		int count = increment("count.dat");
		System.out.println("This program has been run " + count + " times.");
	}

	public static int increment(String path) throws Exception {
		File file = new File(path);
		int count;

		if (!file.exists()) {
			count = 0;
		} else {
			DataInputStream datain = new DataInputStream(new FileInputStream(file));
			count = datain.readInt();
			datain.close();
		}
		
		count++;
		
		DataOutputStream dataout = new DataOutputStream(new FileOutputStream(file));
		dataout.writeInt(count);
		dataout.close();
		
		return count;
	}

}
