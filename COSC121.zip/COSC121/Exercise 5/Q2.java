package exercises;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) throws IOException {
		String webaddress = "https://ok.ubc.ca/welcome.html";
		int count = countText(webaddress, "</a>");
		System.out.println(webaddress + " has " + count + " links.");
	}

	public static int countText(String webaddress, String txt) throws IOException {
		URL url = new URL(webaddress);
		Scanner in = new Scanner(url.openStream());
		int count = 0;
		while(in.hasNext()) {
			if(in.next().contains(txt)) {
				count++;
			}
		}
		in.close();
		return count;
	}

}
