package exercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) throws FileNotFoundException {
		String source = "C:\\Users\\40183402\\eclipse-workspace\\exercises\\src\\source.txt";
		String dest = "C:\\Users\\40183402\\eclipse-workspace\\exercises\\src\\destination.csv";
		copy(source, dest);

	}

	public static void copy(String source, String dest) throws FileNotFoundException {
		try {
			File sourceFile = new File(source);
			File destFile = new File(dest);
			PrintWriter out = new PrintWriter(destFile);
			Scanner in = new Scanner(sourceFile);
			String lastName;
			String firstName;
			String age;
			String id;
			if (destFile.exists()) {
				System.out.println("Warning: dest.csv already exists");
			}

			while (in.hasNext()) {
				lastName = in.nextLine().replaceAll("Last Name:", "");
				firstName = in.nextLine().replaceAll("First Name:", "");
				age = in.nextLine().replaceAll("Age:", "");
				id = in.nextLine().replaceAll("ID:", "");
				out.write(lastName + "," + firstName + "," + age + "," + id + "\n");

			}
			in.close();
			out.close();

		} catch (FileNotFoundException e) {
			System.out.println("Error: file not found");
		}

	}

}
