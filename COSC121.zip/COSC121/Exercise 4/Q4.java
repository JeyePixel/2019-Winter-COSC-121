package A3;

import java.io.*;
import java.util.*;

public class Q4 {
	
	public static void main(String[] args) throws Exception {
		String censoredWords[] = {"ABC", "XYZ"};
		File file = new File("C:\\Users\\Ian\\Desktop\\test\\source.txt");
		//File file2 = new File("C:\\Users\\Ian\\Desktop\\test\\destination.txt");
		Scanner input = new Scanner(file);
		//PrintWriter output = new PrintWriter(file2);
		FileWriter output = new FileWriter("C:\\Users\\Ian\\Desktop\\test\\destination.txt");
		while(input.hasNextLine()) {
			String newLine = replaceCensoredWords(input.nextLine(), censoredWords);
			newLine.toUpperCase();
			System.out.println(newLine);
			output.write(newLine + "\n");
		}
		input.close();
		output.close();
		System.out.println("Done!");
	}
	
	private static String replaceCensoredWords(String line, String[] censoredWords) {
		Scanner input = new Scanner(line);
		String censoredString = input.nextLine();
		for(int i = 0; i < censoredWords.length; i++) {
			if(censoredString.contains(censoredWords[i])) {censoredString = censoredString.replace(censoredWords[i], "...");}
		}
		input.close();
		return censoredString;
	}

}
