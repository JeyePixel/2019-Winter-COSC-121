package A3;

import java.io.*;
import java.util.*;

public class CopyFileCapitalized {

	public static void main(String[] args) throws Exception{
		String[] censoredWords = {"ABC", "XYZ"};

	}
	public static String replaceCensoredWords(String line, String[] censoredWords) {
		return line;
	}

}