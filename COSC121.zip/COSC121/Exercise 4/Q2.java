package A3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Q2 {
	
	public static void main(String[] args) throws InputMismatchException{
		
		//Attributes
		Scanner in = new Scanner(System.in);
		boolean checker = false;
		
		while(!checker) {
			System.out.println("Please enter a a simple mathematical formula: ");
			try {
				double firstnum = in.nextDouble();
				double lastnum = in.nextDouble();
				System.out.println("Result: " + (firstnum + lastnum));
				
				checker = true;
			}catch(InputMismatchException e) { System.out.println("Invalid operator: try again");}
		}
	}
	

}