package A3;

import java.util.Scanner;

public class Q3 {
	
	public static void main(String[] args) throws NumberFormatException{
		
		//Attributes
		Scanner in = new Scanner(System.in);
		boolean checker = false;
		
		while(!checker) {
			System.out.println("Please enter a simple mathematical equation: ");
			String input = in.nextLine();
			try {
			Double equation = Double.parseDouble(input);
			System.out.println("The number you entered was " + equation);
			}catch(NumberFormatException e) { System.out.println("Please enter a valid number!"); }
		}
	}
}