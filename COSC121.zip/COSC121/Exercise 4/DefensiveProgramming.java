package A3;

import java.util.Random;
import java.util.Scanner;

public class DefensiveProgramming {
	
	public static void main(String[] args) {
		
		//Attributes
		boolean checker = false;
		Scanner in = new Scanner(System.in);
		Random rand = new Random();
		int[] intArray = new int[100];
		for(int i = 0; i < intArray.length ; i++) {
			intArray[i] = rand.nextInt();
		}
		
		while(!checker) {
			System.out.println("Please enter an index of the array: ");
			int index = in.nextInt();
			if(index > 99 || index < 0) { System.out.println("That is not a valid index!"); }
			else{ 
				System.out.println("The value at " + index + " is " + intArray[index]); 
				checker = true;
			}
		}
		
	}

}
