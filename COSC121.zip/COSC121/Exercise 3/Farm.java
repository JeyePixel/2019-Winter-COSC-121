package P2;

import java.util.ArrayList;
import java.util.Arrays;

public class Farm {
	private double availableFood;
	private static int numberOfAnimals = 0; //Used to index the array in the add() method
	private Animal[] animals;
	public Farm() {
		setAvailableFood(1000);
		animals = new Animal[100];
		this.add(new Chicken());
		this.add(new Cow());
		this.add(new Llama());
		this.add(new Llama());
	}
	public void makeNoise(){			// all animals make their sound (Moo, Cluck, etc)
		for(Animal animal: animals)
			animal.sound();
	}
	public void feedAnimals(){ 			// restore energy of all animals and deduct amount eaten from availableFood
		for(Animal animal : animals)
			if(availableFood >= animal.getMealAmount())
				availableFood -= animal.eat();
			else
				System.out.println("Not enough food for your animals! You need to collect more food items.");
	}
	public double getAvailableFood() {
		return availableFood;
	}
	public void setAvailableFood(double availableFood) {
		if(availableFood>=0 && availableFood<=1000)
			this.availableFood = availableFood;
	}
	public Animal[] getAnimals() {
		ArrayList<Animal> arrayList = new ArrayList<Animal>();
		for(Animal beasts : animals) { if(beasts != null) {arrayList.add(beasts); }}
		Animal[] animals2 = new Animal[arrayList.size()];
		animals2 = arrayList.toArray(animals2);
		return animals2;
	}
	public static int getNumberOfAnimals() {
		return numberOfAnimals;
	}
	public static void setNumberOfAnimals(int numberOfAnimals) {
		Farm.numberOfAnimals = numberOfAnimals;
	}	
	public boolean add(Animal anim) {
		if(numberOfAnimals <= animals.length) {
			animals[numberOfAnimals] = anim;
			numberOfAnimals++;
			return true;
		}
		else { return false; }
	}
	public void animSort() { 
		Animal[] sortingArray = this.getAnimals();
		Arrays.sort(sortingArray);
		animals = sortingArray.clone();
	}
	public boolean addClone(Animal anim) throws CloneNotSupportedException {
		if(numberOfAnimals <= animals.length) {
			animals[numberOfAnimals] = (Animal) anim.clone();
			return true;
		}
		else { return false; }
	}
	public void printAnimals() {
		for(Animal beasts : animals) {
			if(beasts instanceof Animal) { System.out.println(beasts.toString()); }
		}
	}
	public int getNumChicken() {
		int chickenCount = 0;
		for(Animal beasts : animals) {
			if(beasts instanceof Chicken) { chickenCount++; }
		}
		return chickenCount;
	}
	public int getNumCow() {
		int cowCount = 0;
		for(Animal beasts : animals) {
			if(beasts instanceof Cow) { cowCount++; }
		}
		return cowCount;
	}
	public int getNumLlama() {
		int llamaCount = 0;
		for(Animal beasts : animals) {
			if(beasts instanceof Llama) { llamaCount++; }
		}
		return llamaCount;
	}
	public void printSummary() {
		System.out.println("This farm contains:");
		double animalNumber = this.getNumChicken() + this.getNumCow() + this.getNumLlama();
		System.out.println(animalNumber + " animals, ( " + this.getNumChicken() + " Chickens, " + this.getNumCow() + " Cows, and " + this.getNumLlama() + " Llamas)");
		System.out.println(this.getAvailableFood() + " available units of food");
	}
	
}